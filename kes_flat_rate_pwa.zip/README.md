# K.E. Seifert Flat Rate Guide (PWA)
- React + Vite
- Installable on phone (PWA) with `manifest.json` + `sw.js`
- Tailwind via CDN (no build config needed)

## Quick start
npm i
npm run dev

## Build
npm run build  # outputs to dist/

## Deploy
Upload to Vercel → Framework preset: Vite → Build: npm run build → Output: dist

## Phone install
Open your deployed URL → Add to Home Screen / Install app.
Manager PIN: 1122
