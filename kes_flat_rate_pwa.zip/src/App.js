import React, { useMemo, useState, useEffect } from "react";
import { motion } from "framer-motion";
import {
  Search, Wrench, Calculator, Printer, Download,
  PlusCircle, Trash2, Info, Lock, Unlock, Upload, DollarSign
} from "lucide-react";

/**
 * K.E. Seifert Flat Rate Guide
 * - Techs: see Labor Hours + Total
 * - Managers: unlock with fixed PIN = 1122 to edit rates/fees/parts/tax
 * - Import catalog JSON (replaces fallback). Fallback includes HVAC + Plumbing.
 */

const FALLBACK = {
  "Gas Furnace – No Heat": [
    { id:"gf-igniter", issue:"Failed Hot Surface Igniter", symptoms:"Inducer runs; no ignition; retries then lockout", cause:"Cracked/worn igniter", diagnostics:"Power to igniter; ohms check; inspect for hairline cracks", suggested:"Replace HSI igniter", defaultLaborHrs:0.7, defaultPartsCost:65, defaultQty:1, taxable:true },
    { id:"gf-flame-sensor", issue:"Dirty/Failed Flame Sensor", symptoms:"Burners light 3–10s then shut off", cause:"Oxidation on sensor", diagnostics:"Clean with fine abrasive; verify µA", suggested:"Clean/replace flame sensor", defaultLaborHrs:0.5, defaultPartsCost:25, defaultQty:1, taxable:true },
    { id:"gf-pressure-switch", issue:"Pressure Switch Fault", symptoms:"Inducer runs; pressure switch error", cause:"Weak switch/blocked tubing/condensate", diagnostics:"Manometer test; clear ports; verify vacuum", suggested:"Replace pressure switch if failed", defaultLaborHrs:1.0, defaultPartsCost:85, defaultQty:1, taxable:true },
    { id:"gf-inducer", issue:"Draft Inducer Failure", symptoms:"No start or loud scraping; no draft proven", cause:"Seized bearings/obstruction", diagnostics:"Amp draw; spin test; vacuum at port", suggested:"Replace inducer assembly", defaultLaborHrs:1.8, defaultPartsCost:320, defaultQty:1, taxable:true },
    { id:"gf-gas-valve", issue:"Gas Valve Not Opening", symptoms:"Igniter glows; no flame; 24V at valve", cause:"Failed solenoid/valve", diagnostics:"Inlet pressure; 24V at MV; leak check", suggested:"Replace gas valve & verify combustion", defaultLaborHrs:1.2, defaultPartsCost:220, defaultQty:1, taxable:true }
  ],
  "Oil Furnace – No Heat": [
    { id:"of-nozzle", issue:"Nozzle Clogged/Mis-sized", symptoms:"No/weak flame; short cycling", cause:"Carbon/varnish; wrong GPH", diagnostics:"Replace to spec; set electrodes", suggested:"Replace nozzle and tune", defaultLaborHrs:0.8, defaultPartsCost:18, defaultQty:1, taxable:true },
    { id:"of-igniter", issue:"Ignition Transformer/Igniter", symptoms:"No spark; lockouts", cause:"Weak/failed transformer", diagnostics:"Spark/KV test; leads", suggested:"Replace igniter/transformer", defaultLaborHrs:0.8, defaultPartsCost:140, defaultQty:1, taxable:true }
  ],
  "Heat Pump – No Heat": [
    { id:"hp-defrost", issue:"Failed Defrost Control/Sensor", symptoms:"Outdoor coil frosts; no defrost", cause:"Bad board/sensor", diagnostics:"Ohm sensor; force defrost", suggested:"Replace board/sensor", defaultLaborHrs:1.2, defaultPartsCost:120, defaultQty:1, taxable:true },
    { id:"hp-aux", issue:"Aux Heat Inoperative", symptoms:"Barely warm air", cause:"Open elements/sequencer", diagnostics:"Continuity; W2/AUX call", suggested:"Repair elements or sequencer", defaultLaborHrs:1.0, defaultPartsCost:160, defaultQty:1, taxable:true }
  ],
  "Gas Boiler – No Heat": [
    { id:"gb-ignition", issue:"Ignition Failure (Spark/HSI)", symptoms:"Tries to light then lockout", cause:"Bad igniter/module", diagnostics:"HSI ohms; spark; gas/air", suggested:"Replace igniter/module", defaultLaborHrs:1.2, defaultPartsCost:150, defaultQty:1, taxable:true },
    { id:"gb-circ", issue:"Circulator Pump Failure", symptoms:"Boiler hot; no heat to zones", cause:"Failed pump/relay", diagnostics:"Delta-T; amps; end switch", suggested:"Replace circulator/relay; purge", defaultLaborHrs:1.4, defaultPartsCost:240, defaultQty:1, taxable:true }
  ],
  "Oil Boiler – No Heat": [
    { id:"ob-igniter", issue:"Ignition Transformer/Igniter", symptoms:"No spark; lockouts", cause:"Weak transformer", diagnostics:"KV test; electrodes", suggested:"Replace igniter/transformer", defaultLaborHrs:0.8, defaultPartsCost:140, defaultQty:1, taxable:true },
    { id:"ob-circ", issue:"Circulator/Zone Valve Failure", symptoms:"Boiler hot; space cold", cause:"Failed pump/valve/relay", diagnostics:"End switch; amp draw", suggested:"Replace circulator or zone valve", defaultLaborHrs:1.3, defaultPartsCost:230, defaultQty:1, taxable:true }
  ],
  "Central A/C – No Cool": [
    { id:"ac-cap", issue:"Dual Run Capacitor Failure", symptoms:"Fan/compressor struggle; needs push", cause:"Weak/bad capacitor", diagnostics:"µF test vs nameplate", suggested:"Replace dual run capacitor", defaultLaborHrs:0.5, defaultPartsCost:28, defaultQty:1, taxable:true },
    { id:"ac-fan-motor", issue:"Condenser Fan Motor Failure", symptoms:"Compressor hot; fan not spinning", cause:"Seized/open winding", diagnostics:"Spin test; amps; cap", suggested:"Replace fan motor & capacitor", defaultLaborHrs:1.0, defaultPartsCost:220, defaultQty:1, taxable:true }
  ],
  "Air Handler – No Cool/No Heat (Blower)": [
    { id:"ahm-capacitor", issue:"Blower Capacitor Failure", symptoms:"Weak airflow; motor hums", cause:"Open/weak capacitor", diagnostics:"µF test; bulge/leak", suggested:"Replace blower capacitor", defaultLaborHrs:0.4, defaultPartsCost:18, defaultQty:1, taxable:true },
    { id:"ahm-motor", issue:"Blower Motor Failure", symptoms:"No airflow; trips", cause:"Seized/failed windings/ECM", diagnostics:"Spin; amps; module code", suggested:"Replace blower motor/module", defaultLaborHrs:1.3, defaultPartsCost:320, defaultQty:1, taxable:true }
  ],
  "Ductless Mini-Split – No Cool/Heat": [
    { id:"ms-comm", issue:"Communication Error (IN/OUT)", symptoms:"Error code; outdoor idle", cause:"Polarity/board", diagnostics:"Check S1/S2/S3; LEDs", suggested:"Correct wiring / replace board", defaultLaborHrs:1.0, defaultPartsCost:0, defaultQty:1, taxable:false },
    { id:"ms-refrigerant", issue:"Refrigerant Circuit Issue", symptoms:"Poor cooling/heating; frost", cause:"Leak/restriction", diagnostics:"Weigh in/out; P/T; leak search", suggested:"Repair, evac, weigh in charge", defaultLaborHrs:2.0, defaultPartsCost:80, defaultQty:1, taxable:true }
  ],
  "Plumbing – Flat Rate": [
    { id:"plg-drain-sink", issue:"Drain Clearing – Sink/Tub (Standard)", symptoms:"Slow/no drain; standing water", cause:"Hair/soap/scale in trap/arm", diagnostics:"Remove trap; cable 15–25 ft", suggested:"Clear P-trap/arm; test flow", defaultLaborHrs:0.8, defaultPartsCost:5, defaultQty:1, taxable:true },
    { id:"plg-toilet-rebuild", issue:"Toilet Rebuild – Fill Valve & Flapper", symptoms:"Running toilet; random refills", cause:"Worn flapper/fill valve", diagnostics:"Dye test; fill height", suggested:"Replace fill valve & flapper", defaultLaborHrs:0.9, defaultPartsCost:35, defaultQty:1, taxable:true },
    { id:"plg-faucet-cartridge", issue:"Faucet Cartridge/Stem Replacement", symptoms:"Leaking/hard to turn", cause:"Worn cartridge/stem", diagnostics:"Model ID; isolate supplies", suggested:"Replace cartridge/stem; seats/o-rings", defaultLaborHrs:0.8, defaultPartsCost:40, defaultQty:1, taxable:true },
    { id:"plg-gd-replace", issue:"Garbage Disposal Replacement (1/2–3/4 HP)", symptoms:"Seized/leaks", cause:"Failed motor/housing", diagnostics:"Power; reset; hub leak", suggested:"Replace disposal; cord/hose/gasket", defaultLaborHrs:1.2, defaultPartsCost:180, defaultQty:1, taxable:true },
    { id:"plg-prv", issue:"PRV (Pressure Reducing Valve) Replacement", symptoms:"High pressure; banging; leaks", cause:"Failed diaphragm/spring", diagnostics:"Static >80 PSI; no adjust", suggested:"Replace PRV; set 60–70 PSI", defaultLaborHrs:1.8, defaultPartsCost:160, defaultQty:1, taxable:true },
    { id:"plg-sump", issue:"Sump Pump Replacement (1/3–1/2 HP)", symptoms:"Basement flooding; hot pump", cause:"Failed motor/float", diagnostics:"Amp draw; float; check valve", suggested:"Replace pump; new check valve", defaultLaborHrs:1.5, defaultPartsCost:220, defaultQty:1, taxable:true },
    { id:"plg-toilet-reset", issue:"Toilet Reset – Wax Ring & Bolts", symptoms:"Wobble; leak at base; odor", cause:"Compromised wax/bolts", diagnostics:"Flange height; rock test", suggested:"Pull/reset; new wax/bolts/shims", defaultLaborHrs:0.8, defaultPartsCost:10, defaultQty:1, taxable:true },
    { id:"plg-hose-bib", issue:"Hose Bib Replacement (Frost-Free)", symptoms:"Leaking exterior faucet", cause:"Split stem/packing", diagnostics:"Shutoff; stem length", suggested:"Replace frost-free sillcock; seal", defaultLaborHrs:1.0, defaultPartsCost:45, defaultQty:1, taxable:true },
    { id:"plg-wh-thermocouple", issue:"Water Heater Thermocouple/Flame Sensor", symptoms:"Pilot won’t stay lit", cause:"Weak thermocouple/sensor", diagnostics:"MV test; pilot flame", suggested:"Replace thermocouple/sensor", defaultLaborHrs:0.8, defaultPartsCost:25, defaultQty:1, taxable:true },
    { id:"plg-wh-flush-anode", issue:"Water Heater Flush & Anode Rod", symptoms:"Popping; odor; discoloration", cause:"Sediment; depleted anode", diagnostics:"Purge sediment; inspect anode", suggested:"Flush; replace anode; test relief", defaultLaborHrs:1.2, defaultPartsCost:35, defaultQty:1, taxable:true },
    { id:"plg-leak-copper", issue:"Leak Repair – 1/2\\\" Copper Sweat", symptoms:"Active drip at joint", cause:"Failed solder/pinhole", diagnostics:"Cut back to sound pipe", suggested:"Replace section; sweat coupling", defaultLaborHrs:1.0, defaultPartsCost:15, defaultQty:1, taxable:true },
    { id:"plg-ptrap", issue:"P-Trap Replacement (Sink)", symptoms:"Leak/corrosion/cross-thread", cause:"Worn washers/threads", diagnostics:"Material & alignment", suggested:"Replace P-trap & washers", defaultLaborHrs:0.6, defaultPartsCost:12, defaultQty:1, taxable:true }
  ]
};

function currency(n) {
  if (Number.isNaN(n)) return "$0.00";
  return Number(n).toLocaleString(undefined, { style: "currency", currency: "USD" });
}
function downloadCSV(filename, rows) {
  const csv = rows.map(r => r.map(v => `"${String(v ?? "").replaceAll('"','""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
}

export default function App() {
  // Catalog
  const [catalog, setCatalog] = useState(() => {
    try {
      const raw = localStorage.getItem("hvac_catalog_json");
      return raw ? JSON.parse(raw) : FALLBACK;
    } catch { return FALLBACK; }
  });
  const categories = Object.keys(catalog);
  const [category, setCategory] = useState(categories[0] || "");
  const [query, setQuery] = useState("");
  const issues = (catalog[category] || []).filter(i =>
    [i.issue, i.symptoms, i.cause, i.suggested, i.sku, i.code].filter(Boolean).join(" ").toLowerCase().includes(query.toLowerCase())
  );
  const [selectedId, setSelectedId] = useState(issues[0]?.id || null);
  const selected = issues.find(i => i.id === selectedId) || issues[0];

  // Global pricing
  const [stdRate, setStdRate] = useState(() => Number(localStorage.getItem("hvac_std_rate")) || 165);
  const [afterRate, setAfterRate] = useState(() => Number(localStorage.getItem("hvac_after_rate")) || 267.5);
  const [afterHours, setAfterHours] = useState(() => localStorage.getItem("hvac_after_hours")==="1" || false);
  const [dayStart, setDayStart] = useState(() => localStorage.getItem("hvac_day_start") || "08:00");
  const [dayEnd, setDayEnd] = useState(() => localStorage.getItem("hvac_day_end") || "16:30");
  const [tripFee, setTripFee] = useState(() => Number(localStorage.getItem("hvac_trip_fee")) || 89);
  const [taxPct, setTaxPct] = useState(() => Number(localStorage.getItem("hvac_tax_pct")) || 0);
  const [partsMarkupPct, setPartsMarkupPct] = useState(() => Number(localStorage.getItem("hvac_parts_markup")) || 35);

  useEffect(() => {
    localStorage.setItem("hvac_std_rate", String(stdRate));
    localStorage.setItem("hvac_after_rate", String(afterRate));
    localStorage.setItem("hvac_after_hours", afterHours ? "1" : "0");
    localStorage.setItem("hvac_day_start", dayStart);
    localStorage.setItem("hvac_day_end", dayEnd);
    localStorage.setItem("hvac_trip_fee", String(tripFee));
    localStorage.setItem("hvac_tax_pct", String(taxPct));
    localStorage.setItem("hvac_parts_markup", String(partsMarkupPct));
  }, [stdRate, afterRate, afterHours, dayStart, dayEnd, tripFee, taxPct, partsMarkupPct]);

  // Manager PIN (fixed to 1122)
  const [managerUnlocked, setManagerUnlocked] = useState(false);
  const [pinInput, setPinInput] = useState("");

  // Line item inputs
  const [laborHrs, setLaborHrs] = useState(selected?.defaultLaborHrs ?? 1);
  const [parts, setParts] = useState(selected?.defaultPartsCost ?? 0);
  const [qty, setQty] = useState(selected?.defaultQty ?? 1);

  useEffect(() => {
    setLaborHrs(selected?.defaultLaborHrs ?? 1);
    setParts(selected?.defaultPartsCost ?? 0);
    setQty(selected?.defaultQty ?? 1);
  }, [selected?.id]);

  const effectiveLaborRate = afterHours ? afterRate : stdRate;
  const calc = useMemo(() => {
    const partsSubtotal = (Number(parts) * Number(qty)) * (1 + Number(partsMarkupPct)/100);
    const laborSubtotal = Number(laborHrs) * Number(effectiveLaborRate);
    const subtotal = Number(tripFee) + partsSubtotal + laborSubtotal;
    const tax = subtotal * (Number(taxPct)/100);
    const total = subtotal + tax;
    return { partsSubtotal, laborSubtotal, subtotal, tax, total };
  }, [parts, qty, partsMarkupPct, laborHrs, effectiveLaborRate, tripFee, taxPct]);

  // Saved quotes
  const [saved, setSaved] = useState(() => {
    try { return JSON.parse(localStorage.getItem("hvac_quotes") || "[]"); } catch { return []; }
  });
  function saveQuote() {
    if (!selected) return;
    const q = { ts: Date.now(), category, issue: selected.issue, laborRate: effectiveLaborRate, laborHrs, tripFee, parts, qty, partsMarkupPct, taxPct, total: calc.total };
    const next = [q, ...saved].slice(0, 200);
    setSaved(next);
    localStorage.setItem("hvac_quotes", JSON.stringify(next));
  }
  function exportQuotes() {
    const header = managerUnlocked
      ? ["Date","Category","Issue","Labor Rate","Hours","Trip","Parts","Qty","Markup%","Tax%","Total"]
      : ["Date","Category","Issue","Total"];
    const rows = [header, ...saved.map(s =>
      managerUnlocked
        ? [new Date(s.ts).toLocaleString(), s.category, s.issue, String(s.laborRate), String(s.laborHrs), String(s.tripFee), String(s.parts), String(s.qty), String(s.partsMarkupPct), String(s.taxPct), String(Math.round(s.total*100)/100)]
        : [new Date(s.ts).toLocaleString(), s.category, s.issue, String(Math.round(s.total*100)/100)]
    )];
    downloadCSV("quotes.csv", rows);
  }
  function removeSaved(ts) {
    const next = saved.filter(s => s.ts !== ts);
    setSaved(next);
    localStorage.setItem("hvac_quotes", JSON.stringify(next));
  }

  async function handleImport(file) {
    const text = await file.text();
    try {
      const parsed = JSON.parse(text);
      if (!parsed || typeof parsed !== "object") throw new Error();
      setCatalog(parsed);
      localStorage.setItem("hvac_catalog_json", text);
      const first = Object.keys(parsed)[0];
      if (first) { setCategory(first); setSelectedId(null); setQuery(""); }
    } catch {
      alert("Invalid catalog JSON.");
    }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="mx-auto max-w-6xl p-4 sm:p-6">
        <header className="mb-4 sm:mb-6 rounded-2xl bg-amber-50 border border-amber-200 p-3 sm:p-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-3">
              <img src="/logo.svg" alt="K.E. Seifert" className="h-16 w-auto" />
              <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight">
                K.E. Seifert Flat Rate Guide
              </h1>
            </div>
            <div className="grid grid-cols-2 sm:flex gap-2 sm:gap-3">
              <label className="inline-flex items-center gap-2 rounded-2xl border px-3 py-2 bg-white hover:bg-slate-50 cursor-pointer">
                <Upload className="w-4 h-4"/>
                <span>Import Catalog JSON</span>
                <input type="file" accept="application/json" className="hidden"
                  onChange={e => { const f = e.target.files?.[0]; if (f) handleImport(f); }}/>
              </label>
              <button onClick={saveQuote} className="inline-flex items-center gap-2 rounded-2xl shadow px-3 py-2 bg-amber-600 text-white hover:bg-amber-700">
                <PlusCircle className="w-4 h-4" /> Save Quote
              </button>
              <button onClick={() => window.print()} className="inline-flex items-center gap-2 rounded-2xl shadow px-3 py-2 bg-white border hover:bg-slate-50">
                <Printer className="w-4 h-4" /> Print
              </button>
              <button onClick={exportQuotes} className="inline-flex items-center gap-2 rounded-2xl shadow px-3 py-2 bg-white border hover:bg-slate-50">
                <Download className="w-4 h-4" /> Export CSV
              </button>
            </div>
          </div>
        </header>

        <section className="mb-4">
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            {managerUnlocked ? (
              <button onClick={() => setManagerUnlocked(false)} className="inline-flex items-center gap-2 rounded-2xl px-3 py-2 bg-amber-600 text-white">
                <Unlock className="w-4 h-4" /> Manager Unlocked
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <input type="password" placeholder="PIN" className="rounded-xl border px-3 py-2 w-28"
                  value={pinInput} onChange={e=>setPinInput(e.target.value)} />
                <button onClick={() => { if (pinInput === "1122") { setManagerUnlocked(true); setPinInput(""); } }}
                  className="inline-flex items-center gap-2 rounded-2xl px-3 py-2 bg-white border">
                  <Lock className="w-4 h-4" /> Unlock
                </button>
              </div>
            )}
          </div>

          {managerUnlocked ? (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-7 gap-2">
                <Control label="Std Labor Rate ($/hr)"><input type="number" className="w-full rounded-xl border px-3 py-2" value={stdRate} onChange={e => setStdRate(Number(e.target.value))}/></Control>
                <Control label="After-Hours Rate ($/hr)"><input type="number" className="w-full rounded-xl border px-3 py-2" value={afterRate} onChange={e => setAfterRate(Number(e.target.value))}/></Control>
                <Control label="Business Hours Start"><input type="time" className="w-full rounded-xl border px-3 py-2" value={dayStart} onChange={e => setDayStart(e.target.value)}/></Control>
                <Control label="Business Hours End"><input type="time" className="w-full rounded-xl border px-3 py-2" value={dayEnd} onChange={e => setDayEnd(e.target.value)}/></Control>
                <Control label="After Hours?"><div className="flex items-center gap-2"><input id="afterhours" type="checkbox" className="rounded" checked={afterHours} onChange={e => setAfterHours(e.target.checked)}/><label htmlFor="afterhours" className="text-sm text-slate-700">Use after-hours</label></div></Control>
                <Control label="Trip Fee ($)"><input type="number" className="w-full rounded-xl border px-3 py-2" value={tripFee} onChange={e => setTripFee(Number(e.target.value))}/></Control>
                <Control label="Sales Tax (%)"><input type="number" className="w-full rounded-xl border px-3 py-2" value={taxPct} onChange={e => setTaxPct(Number(e.target.value))}/></Control>
              </div>
              <div className="mt-2 text-sm text-slate-600">
                Active labor rate: <span className="font-medium">{currency(effectiveLaborRate)}</span> {afterHours ? "(After Hours)" : "(Standard)"}
              </div>
            </>
          ) : null}
        </section>

        <div className="grid md:grid-cols-2 gap-4">
          <section className="bg-white rounded-2xl shadow p-3 sm:p-4">
            <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-3">
              <select value={category} onChange={e => { setCategory(e.target.value); setSelectedId(null); setQuery(""); }} className="rounded-xl border px-3 py-2">
                {categories.map(c => <option key={c}>{c}</option>)}
              </select>
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500"/>
                <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search issues, symptoms, causes, SKU…" className="w-full rounded-xl border pl-9 pr-3 py-2"/>
              </div>
            </div>

            <ul className="divide-y">
              {(issues.length ? issues : []).map((i) => (
                <li key={i.id || i.issue} className={`py-3 cursor-pointer ${selected?.id === i.id ? "bg-slate-50" : ""}`} onClick={() => setSelectedId(i.id || null)}>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-medium">{i.issue}</div>
                      <div className="text-sm text-slate-600">{i.symptoms}</div>
                    </div>
                    <Wrench className="w-4 h-4 text-slate-400"/>
                  </div>
                </li>
              ))}
            </ul>
          </section>

          <section className="bg-white rounded-2xl shadow p-3 sm:p-4">
            {selected && (
              <div className="space-y-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h2 className="text-lg font-semibold">{selected.issue}</h2>
                    <p className="text-sm text-slate-600">{category}</p>
                  </div>
                  <div className="inline-flex items-center gap-2 rounded-xl px-2 py-1 border text-slate-700 bg-slate-50"><Info className="w-4 h-4"/> Troubleshooting</div>
                </div>

                <div className="grid sm:grid-cols-2 gap-3">
                  <Tip title="Quick Symptoms" text={selected.symptoms || ""} />
                  <Tip title="Likely Cause/Parts" text={selected.cause || ""} />
                  <Tip title="Diagnostic Notes" text={selected.diagnostics || ""} />
                  <Tip title="Suggested Line Item" text={selected.suggested || ""} />
                </div>

                <div className="border-t pt-3">
                  <h3 className="font-semibold mb-2 flex items-center gap-2"><Calculator className="w-4 h-4"/> Price</h3>

                  {!managerUnlocked && (
                    <>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        <Control label="Labor Hours">
                          <input
                            type="number"
                            step="0.1"
                            className="w-full rounded-xl border px-3 py-2"
                            value={laborHrs}
                            onChange={e => setLaborHrs(Number(e.target.value))}
                          />
                        </Control>
                      </div>
                      <div className="mt-3 grid sm:grid-cols-3 gap-2 text-sm">
                        <Summary label="Total" value={currency(calc.total)} emphasize/>
                        <Summary label="Trip" value="Included"/>
                        <Summary label="Tax" value="Included"/>
                      </div>
                    </>
                  )}

                  {managerUnlocked && (
                    <>
                      <div className="grid grid-cols-2 sm:grid-cols-6 gap-2">
                        <Control label="Labor Hours"><input type="number" step="0.1" className="w-full rounded-xl border px-3 py-2" value={laborHrs} onChange={e => setLaborHrs(Number(e.target.value))}/></Control>
                        <Control label="Parts Cost ($)"><input type="number" className="w-full rounded-xl border px-3 py-2" value={parts} onChange={e => setParts(Number(e.target.value))}/></Control>
                        <Control label="Quantity"><input type="number" className="w-full rounded-xl border px-3 py-2" value={qty} onChange={e => setQty(Number(e.target.value))}/></Control>
                        <Control label="Parts Markup (%)"><input type="number" className="w-full rounded-xl border px-3 py-2" value={partsMarkupPct} onChange={e => setPartsMarkupPct(Number(e.target.value))}/></Control>
                        <Control label="Trip Fee ($)"><input type="number" className="w-full rounded-xl border px-3 py-2" value={tripFee} onChange={e => setTripFee(Number(e.target.value))}/></Control>
                        <Control label="Sales Tax (%)"><input type="number" className="w-full rounded-xl border px-3 py-2" value={taxPct} onChange={e => setTaxPct(Number(e.target.value))}/></Control>
                      </div>

                      <div className="mt-3 grid sm:grid-cols-5 gap-2 text-sm">
                        <Summary label="Labor" value={`${laborHrs} hr × ${currency(effectiveLaborRate)} = ${currency(calc.laborSubtotal)}`}/>
                        <Summary label="Parts" value={`${qty} × ${currency(parts)} → markup ${partsMarkupPct}% = ${currency(calc.partsSubtotal)}`}/>
                        <Summary label="Trip" value={currency(tripFee)}/>
                        <Summary label="Tax" value={`${taxPct}% = ${currency(calc.tax)}`}/>
                        <Summary label="Total" value={currency(calc.total)} emphasize/>
                      </div>
                    </>
                  )}
                </div>

                <div className="flex flex-wrap gap-2">
                  <button onClick={saveQuote} className="inline-flex items-center gap-2 rounded-2xl shadow px-3 py-2 bg-amber-600 text-white hover:bg-amber-700"><DollarSign className="w-4 h-4"/> Save this price</button>
                  <button onClick={() => { setLaborHrs(selected.defaultLaborHrs ?? 1); setParts(selected.defaultPartsCost ?? 0); setQty(selected.defaultQty ?? 1); }} className="inline-flex items-center gap-2 rounded-2xl shadow px-3 py-2 bg-white border hover:bg-slate-50"><span className="w-4 h-4">↺</span> Reset defaults</button>
                </div>
              </div>
            )}
          </section>
        </div>

        <section className="mt-6 bg-white rounded-2xl shadow p-3 sm:p-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-semibold">Saved Quotes</h3>
            <div className="text-sm text-slate-500">Stored on this device</div>
          </div>
          {saved.length === 0 ? (
            <p className="text-slate-600 text-sm">No quotes yet.</p>
          ) : (
            <div className="overflow-x-auto">
              {managerUnlocked ? (
                <table className="min-w-full text-sm">
                  <thead>
                    <tr className="text-left text-slate-600">
                      <th className="py-2 pr-4">Date</th>
                      <th className="py-2 pr-4">Category</th>
                      <th className="py-2 pr-4">Issue</th>
                      <th className="py-2 pr-4">Labor Rate</th>
                      <th className="py-2 pr-4">Hours</th>
                      <th className="py-2 pr-4">Trip</th>
                      <th className="py-2 pr-4">Parts</th>
                      <th className="py-2 pr-4">Qty</th>
                      <th className="py-2 pr-4">Markup%</th>
                      <th className="py-2 pr-4">Tax%</th>
                      <th className="py-2 pr-4">Total</th>
                      <th className="py-2 pr-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {saved.map(s => (
                      <tr key={s.ts} className="border-t">
                        <td className="py-2 pr-4 whitespace-nowrap">{new Date(s.ts).toLocaleString()}</td>
                        <td className="py-2 pr-4">{s.category}</td>
                        <td className="py-2 pr-4">{s.issue}</td>
                        <td className="py-2 pr-4">{currency(s.laborRate)}</td>
                        <td className="py-2 pr-4">{s.laborHrs}</td>
                        <td className="py-2 pr-4">{currency(s.tripFee)}</td>
                        <td className="py-2 pr-4">{currency(s.parts)}</td>
                        <td className="py-2 pr-4">{s.qty}</td>
                        <td className="py-2 pr-4">{s.partsMarkupPct}%</td>
                        <td className="py-2 pr-4">{s.taxPct}%</td>
                        <td className="py-2 pr-4 font-semibold">{currency(s.total)}</td>
                        <td className="py-2 pr-4">
                          <button onClick={() => removeSaved(s.ts)} className="inline-flex items-center gap-1 rounded-xl px-2 py-1 border hover:bg-slate-50">
                            <Trash2 className="w-4 h-4"/>Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <table className="min-w-full text-sm">
                  <thead>
                    <tr className="text-left text-slate-600">
                      <th className="py-2 pr-4">Date</th>
                      <th className="py-2 pr-4">Category</th>
                      <th className="py-2 pr-4">Issue</th>
                      <th className="py-2 pr-4">Total</th>
                      <th className="py-2 pr-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {saved.map(s => (
                      <tr key={s.ts} className="border-t">
                        <td className="py-2 pr-4 whitespace-nowrap">{new Date(s.ts).toLocaleString()}</td>
                        <td className="py-2 pr-4">{s.category}</td>
                        <td className="py-2 pr-4">{s.issue}</td>
                        <td className="py-2 pr-4 font-semibold">{currency(s.total)}</td>
                        <td className="py-2 pr-4">
                          <button onClick={() => removeSaved(s.ts)} className="inline-flex items-center gap-1 rounded-xl px-2 py-1 border hover:bg-slate-50">
                            <Trash2 className="w-4 h-4"/>Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          )}
        </section>

        <footer className="text-xs text-slate-500 mt-6">© {new Date().getFullYear()} – K.E. Seifert, internal use only.</footer>
      </div>
    </div>
  );
}

function Control({ label, children }) {
  return (
    <label className="text-sm">
      <div className="text-slate-600 mb-1">{label}</div>
      {children}
    </label>
  );
}
function Tip({ title, text }) {
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border p-3 bg-slate-50">
      <div className="text-xs uppercase tracking-wider text-slate-500 mb-1">{title}</div>
      <div className="text-slate-800 text-sm leading-relaxed whitespace-pre-wrap">{text}</div>
    </motion.div>
  );
}
function Summary({ label, value, emphasize }) {
  return (
    <div className={`rounded-xl border p-2 ${emphasize ? "bg-amber-50 border-amber-200" : "bg-slate-50"}`}>
      <div className="text-xs text-slate-500">{label}</div>
      <div className={`font-medium ${emphasize ? "text-amber-700" : "text-slate-800"}`}>{value}</div>
    </div>
  );
}
